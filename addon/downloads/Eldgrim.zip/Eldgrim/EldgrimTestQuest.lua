-- A test quest for the hearth board. Empty in the download: it is used only
-- on the founder's client while developing the addon.

EldgrimTestQuestFile = {
    quest = nil,
}
